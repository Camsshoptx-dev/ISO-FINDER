-- Run once in Supabase: SQL Editor > New query > paste > Run
create table if not exists iso_users (
  email text primary key,
  plan text not null default 'free',
  monthly_limit int,            -- null = use the app default
  blocked boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists iso_reads (
  id bigint generated always as identity primary key,
  email text not null references iso_users(email),
  status text not null default 'pending',   -- pending | ok | failed
  at timestamptz not null default now()
);
create index if not exists iso_reads_email_at on iso_reads(email, at);
-- Lock the tables so only your server key can touch them (the app uses the service key).
alter table iso_users enable row level security;
alter table iso_reads enable row level security;
